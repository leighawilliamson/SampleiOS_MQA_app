//
//  utestMasterViewController.h
//  helloWorldApphanceIntegration
//
//  Created by Wojciech Kedzierski on 31.08.2012.
//  Copyright (c) 2012 Wojciech Kedzierski. All rights reserved.
//

#import <UIKit/UIKit.h>

@class utestDetailViewController;

@interface utestMasterViewController : UITableViewController

@property (strong, nonatomic) utestDetailViewController *detailViewController;

@end
