//
//  utestLogObject.h
//  helloWorldApphanceIntegration
//
//  Created by Stanton Champion on 9/11/12.
//  Copyright (c) 2012 Wojciech Kedzierski. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface utestLogObject : NSObject

- (void) testMethod;

@end
