//
//  utestAppDelegate.h
//  helloWorldApphanceIntegration
//
//  Created by Wojciech Kedzierski on 31.08.2012.
//  Copyright (c) 2012 Wojciech Kedzierski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface utestAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
