//
//  helloWorldApphanceIntegrationTests.m
//  helloWorldApphanceIntegrationTests
//
//  Created by Wojciech Kedzierski on 31.08.2012.
//  Copyright (c) 2012 Wojciech Kedzierski. All rights reserved.
//

#import "helloWorldApphanceIntegrationTests.h"

@implementation helloWorldApphanceIntegrationTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in helloWorldApphanceIntegrationTests");
}

@end
