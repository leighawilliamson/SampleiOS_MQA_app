//
//  helloWorldApphanceIntegrationTests.h
//  helloWorldApphanceIntegrationTests
//
//  Created by Wojciech Kedzierski on 31.08.2012.
//  Copyright (c) 2012 Wojciech Kedzierski. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface helloWorldApphanceIntegrationTests : SenTestCase

@end
